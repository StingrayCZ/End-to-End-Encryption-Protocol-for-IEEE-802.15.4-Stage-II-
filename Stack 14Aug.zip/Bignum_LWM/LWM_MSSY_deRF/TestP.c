#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int TestP(){
	
	
	volatile BB pole;

	
	
	int delka, val;
	uint8_t *array;

	pole = bdNew();
	
	bdConvFromHex(pole, "f");
	
	

	delka = bdConvToDecimal(pole, NULL, 0);
	array = malloc(delka);
	bdConvToDecimal(pole, array, delka);
	
	printf("array is %d \n\r", array);
	
	
	val = atoi(array);
	
	printf("array is %d \n\r", val);
	
		
}