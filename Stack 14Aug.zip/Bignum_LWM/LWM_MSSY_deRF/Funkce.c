#include <avr/io.h>
/*- Includes ---------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "config.h"
#include "hal.h"
#include "phy.h"
#include "sys.h"
#include "nwk.h"
#include "sysTimer.h"
#include "halBoard.h"
#include "halUart.h"
//#include "mssy_endpoints.h"
//#include "mssy_requests.h"
#include "mssy_functions.h"
#include "util/delay.h"
#include "ADC_lib.h"
#include "main.h"
#include "sensors_interface.h"

/////USB//////////////
#include "USB_Stack/usb.h"

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"


/*************************************************************************/
/*************************************************************************/
/**FUNKCE
*****************************************************************************
*****************************************************************************/

/*************************************************************************/
/**FERMAT TEST
*****************************************************************************/
int fermat_test(BIGD n)
{
/* Carries out a quick Fermat primality test on n > 4.
   Returns 1 if n is prime and 0 if composite or -1 if n < 5.
   This is not foolproof but we use it as a 
   check on our main bdIsPrime function.
   It will return a false positive for Fermat Liars, which
   are very rare.
*/
	BIGD a, e, r;
	int isprime = 1;

	/* For any integer a, 1<=a<=n-1, if a^(n-1) mod n != 1
	   then n is composite. */

	if (bdShortCmp(n, 5) < 0) return -1;

	a = bdNew();
	e = bdNew();
	r = bdNew();
	/* e = n -1 */
	bdSetEqual(e, n);
	bdDecrement(e);

	/* Set a = 2 and compute a^(n-1) mod n */
	bdSetShort(a, 2);
	bdModExp(r, a, e, n);
	if (bdShortCmp(r, 1) != 0)
		isprime = 0;

	/* a = 3 */
	bdSetShort(a, 3);
	bdModExp(r, a, e, n);
	if (bdShortCmp(r, 1) != 0)
		isprime = 0;

	/* a = 5 */
	bdSetShort(a, 5);
	bdModExp(r, a, e, n);
	if (bdShortCmp(r, 1) != 0)
		isprime = 0;

	bdFree(&a);
	bdFree(&e);
	bdFree(&r);

	return isprime;
}