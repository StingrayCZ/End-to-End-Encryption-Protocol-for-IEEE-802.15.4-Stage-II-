/*
 * LWM_MSSY_deRF.c
 *
 * Created: 14.4.2017 12:56:52
 * Author : Ondra
 */ 

#include <avr/io.h>
/*- Includes ---------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "config.h"
#include "hal.h"
#include "phy.h"
#include "sys.h"
#include "nwk.h"
#include "sysTimer.h"
#include "halBoard.h"
#include "halUart.h"
//#include "mssy_endpoints.h"
//#include "mssy_requests.h"
#include "mssy_functions.h"
#include "util/delay.h"
#include "ADC_lib.h"
#include "main.h"
#include "sensors_interface.h"

/////USB//////////////
#include "USB_Stack/usb.h"

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"

#define EMPTYLINE printf("\n\r");
#define BB BIGD

/*- Definitions ------------------------------------------------------------*/
#ifdef NWK_ENABLE_SECURITY
#define APP_BUFFER_SIZE     (NWK_MAX_PAYLOAD_SIZE - NWK_SECURITY_MIC_SIZE)
#else
#define APP_BUFFER_SIZE     NWK_MAX_PAYLOAD_SIZE
#endif

/*- Types ------------------------------------------------------------------*/
typedef enum AppState_t
{
	APP_STATE_FazeA,
	APP_STATE_FazeB,
	APP_STATE_FazeC,
} AppState_t;

/*- Prototypes -------------------------------------------------------------*/
static void appSendData(void);

//int TestB(void);

/*- Variables --------------------------------------------------------------*/
static AppState_t appState = APP_STATE_FazeA;    // Prvotni faze

static SYS_Timer_t appTimerA;
static SYS_Timer_t appTimerB;

static NWK_DataReq_t appDataReq;
static bool appDataReqBusy = false;


// USB printf
FILE usb_stream = FDEV_SETUP_STREAM(usb_putc_std, usb_getc_std,_FDEV_SETUP_RW);


/*- Implementations --------------------------------------------------------*/

/*************************************************************************//**
*****************************************************************************/
static void appDataConf(NWK_DataReq_t *req)
{
appDataReqBusy = false;
(void)req;
}

/*************************************************************************//**
*****************************************************************************/
static void SendDataA(void)
{
	//if (appDataReqBusy || 0 == appUartBufferPtr)
	//return;
//
	//memcpy(appDataReqBuffer, appUartBuffer, appUartBufferPtr);

	appDataReq.dstAddr = 0xFFFF;
	appDataReq.dstEndpoint = 2;
	appDataReq.srcEndpoint = 1;
	//appDataReq.options = NWK_OPT_ENABLE_SECURITY;
	appDataReq.data = 65;
	appDataReq.size = 1;
	appDataReq.confirm = appDataConf;
	NWK_DataReq(&appDataReq);


	appDataReqBusy = true;
	
	
	// Posilam data data
	printf("Odeslana data: ", appDataReq.data);
	
}


/*************************************************************************//**
*****************************************************************************/
static void SendDataA_TimerHandler(SYS_Timer_t *timer)
{
	SendDataA();
	//(void)timer;  // proc??
}


/*************************************************************************//**
*****************************************************************************/

static bool DostavamData(NWK_DataInd_t *ind)
{

	volatile uint16_t ObtainData;

	ObtainData= ind->data;
	
	
	// Tisk obdrzenych hodnot
	printf("Obdrzena data %D \r\n", ObtainData);
	
	}



/*************************************************************************//**
*****************************************************************************/
static void appInit(void)
{
NWK_SetAddr(APP_ADDR);
NWK_SetPanId(APP_PANID);
PHY_SetChannel(APP_CHANNEL);
#ifdef PHY_AT86RF212
PHY_SetBand(APP_BAND);
PHY_SetModulation(APP_MODULATION);
#endif
PHY_SetRxState(true);

NWK_OpenEndpoint(1, DostavamData);              // Endpoint
NWK_OpenEndpoint(2, DostavamData);              // Endpoint

//NWK_OpenEndpoint(APP_ENDPOINT, DostavamData);   // Endpoint


//NWK_OpenEndpoint(APP_ENDPOINT, appDataInd);

HAL_BoardInit();

appTimerA.interval = 1000;
//appTimerA.mode = SYS_TIMER_INTERVAL_MODE;
appTimerA.mode = SYS_TIMER_PERIODIC_MODE;
appTimerA.handler = SendDataA_TimerHandler;


}

/*************************************************************************//**
*****************************************************************************/
static void APP_TaskHandler(void)
{
switch (appState)
{
case APP_STATE_FazeA:
{
appInit();


} break;

default:
break;
}
}


/*************************************************************************/
int main(void)
{
	usb_init();
   /* redirect standard input/output (like printf()) to USB stream */
	stdout = &usb_stream;
	stdin  = &usb_stream;
	LED1ON;
	//printf("Hello :-) \n\r");
	
	
	EMPTYLINE
	
	printf("Test Lambda Diff\n\r");
	
	//BB RESULT, MOD, Lambda, X, Y, X_k;
	//
	//RESULT = bdNew();
	//MOD = bdNew();
	//X = bdNew();
	//Y= bdNew();
	//Lambda = bdNew();
	//X_k = bdNew();
	//
	//
	//bdConvFromHex(MOD, "b");
	//bdConvFromHex(Lambda, "5");
	//bdConvFromHex(X, "a");
	//bdConvFromHex(Y, "2");
	//bdConvFromHex(X_k, "2");
		//
	//YUniBIGD(RESULT, MOD, Lambda, X, Y, X_k);
	//bdPrintDecimal("Resulcft ", RESULT, " \n\r");
	//
	//
	//bdFree(&MOD);
	//bdFree(&X);
	//bdFree(&Y);
	//bdFree(&X_k);
	//bdFree(&Lambda);
	
	
	EMPTYLINE
	
	printf("Recogniser \n\r");
	
	
	BB  X,  Y, a, mod, ResultX, ResultY;
	int RESULT;
	
	
	X = bdNew();
	Y = bdNew();
	a = bdNew();
	mod = bdNew();
	
	ResultX = bdNew();
	ResultY = bdNew();

	bdConvFromHex(X, "2");
	bdConvFromHex(Y, "4");
	bdConvFromHex(a, "1");
	bdConvFromHex(mod, "7");
	
	uint32_t iteration = 3;
	int STOPval;

	
	printf("Point Comp \n\r");
	
	//PointCompBIGD(BB X, BB Y, BB a_asymptote, BB modulus, uint32_t *iteration, ResultX, ResultY, int *STOPval)
	
	PointCompBIGD(X, Y, a, mod, ResultX, ResultY, &iteration, &STOPval);
	
	bdPrintDecimal("X", ResultX, " \n\r");
	bdPrintDecimal("Y", ResultY, " \n\r");
	
	printf("cislo stopval je %d = \n\r", STOPval);
		


	while(1)
	{
		SYS_TaskHandler();
		APP_TaskHandler();
		
	}
}