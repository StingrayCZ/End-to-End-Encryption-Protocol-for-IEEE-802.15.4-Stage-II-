#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");


int XDiffBIGD(BB RESULT, BB MOD, BB Lambda, BB Xi, BB Xj)
{

	BB mod, lambda, xi, xj;
	BB resultA, resultB, resultC, resultD, resultE;    // auxiliary
	
	assert(RESULT && MOD && Lambda && Xi && Xj);
	
	int compare;
	
	mod = bdNew();
	lambda = bdNew();
	xi = bdNew();
	xj = bdNew();
	
	resultA = bdNew();
	resultB = bdNew();
	resultC = bdNew();
	resultD = bdNew();
	resultE = bdNew();
	
	bdSetEqual(mod, MOD);
	bdSetEqual(lambda, Lambda);
	bdSetEqual(xi, Xi);
	bdSetEqual(xj, Xj);
	
	
	bdSquare(resultA, lambda);
	
	compare = bdCompare(resultA, xi);
	
	if(compare == 1){
		
		bdSubtract(resultB, resultA, xi);
		
	}
	
	else if(compare == (-1)){
		
		bdSubtract(resultB, xi, resultA);
		
	}
	
	compare = bdCompare(resultB, xj);
	
	
	if(compare == 1){
		
		bdSubtract(resultC, resultB, xj);
		
		bdModulo(resultE, resultC, mod);
		
	}
	
	else if(compare == (-1)){
		
		bdSubtract(resultC, xj, resultB);
		
		bdModulo(resultD, resultC, mod);
		
		bdSubtract(resultE, mod, resultD);
		
	}

	bdSetEqual(RESULT, resultE);

	
	bdFree(&mod);
	bdFree(&lambda);
	bdFree(&xi);
	bdFree(&xj);
	
	bdFree(&resultA);
	bdFree(&resultB);
	bdFree(&resultC);
	bdFree(&resultD);
	bdFree(&resultE);

	return 0;
}