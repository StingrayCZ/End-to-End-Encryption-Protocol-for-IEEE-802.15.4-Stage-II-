#include <stdio.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int YUniBIGD(BB RESULT, BB MOD, BB Lambda, BB X, BB Y, BB X_k)
{
	
	
	assert(RESULT && MOD && Lambda && X && Y && X_k);
	
	int compareA, compareB;
	
	BB mod, lambda, x, x_k, y;
	BB resultA, resultB, resultC, resultD, resultE;
	
	mod = bdNew();
	lambda= bdNew();
	x = bdNew();
	y = bdNew();
	x_k = bdNew();
	
	resultA = bdNew();
	resultB = bdNew();
	resultC = bdNew();
	resultD = bdNew();
	resultE = bdNew();
	
	
	bdSetEqual(mod, MOD);
	bdSetEqual(lambda, Lambda);
	bdSetEqual(x, X);
	bdSetEqual(y, Y);
	bdSetEqual(x_k, X_k);
	
	
	compareA = bdCompare(x, x_k);
	
	if(compareA == 1){
		
		bdSubtract(resultA, x, x_k);
		bdMultiply(resultB, lambda, resultA);
		
		compareB = bdCompare(resultB, y);
		
		if(compareB == 1){
			bdSubtract(resultC, resultB, y);
			bdModulo(resultE, resultC, mod);
		}
		else if(compareB == (-1)){
			bdSubtract(resultC, y, resultB);
			bdModulo(resultD, resultC, mod);
			bdSubtract(resultE, mod, resultD);
		}
	}
	else if(compareA == (-1)){
		
		bdSubtract(resultA, x_k, x);
		bdMultiply(resultB, lambda, resultA);	
		bdAdd(resultC, resultB, y);
		bdModulo(resultD, resultC, mod);
		bdSubtract(resultE, mod, resultD);
		
	}
	
		bdSetEqual(RESULT, resultE);  
		
		
	bdFree(&mod);
	bdFree(&lambda);
	bdFree(&x);
	bdFree(&x_k);

	bdFree(&resultA);
	bdFree(&resultB);
	bdFree(&resultC);
	bdFree(&resultD);
	bdFree(&resultE);
	
	
	return 0;

}