#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");
#define PRINT


void ECDH_PHASE_C_BIGD(BB Xm, BB Ym, BB Xo, BB Yo, BB MOD, BB a, BB KEY)
{
	
	BB Xa, Ya, Xb, Yb, mod, a_pam;
	volatile BB results[2];
	BB X, Y, Key;
	
	Xa = bdNew();
	Ya = bdNew();
	Xb = bdNew();
	Yb = bdNew();
	mod = bdNew();
	a_pam = bdNew();
	
	results[0] = bdNew();
	results[1] = bdNew();
	results[2] = bdNew();
	
	Key = bdNew();
	X = bdNew();
	Y = bdNew();	
	
	bdSetEqual(Xa, Xm);
	bdSetEqual(Ya, Ym);
	bdSetEqual(Xb, Xo);
	bdSetEqual(Yb, Xo);
	
	bdSetEqual(a_pam, a);
	
	SumTwoPointsBIGD(Xa, Ya, Xb, Yb, MOD, a_pam, results);
	
	bdSetEqual(X ,results[0]);
	bdSetEqual(Y ,results[1]);
	
	MagnifierKeyBig(Key, X, Y);
	
	
	bdSetEqual(KEY ,Key);
	

	// Flush Objects
	bdFree(&Xa);
	bdFree(&Ya);
	bdFree(&Xb);
	bdFree(&Yb);
	bdFree(&mod);
	bdFree(&a_pam);
	
	bdFree(&results[0]);
	bdFree(&results[1]);
	bdFree(&results[2]);
	
	bdFree(&X);
	bdFree(&Y);
	bdFree(&Key);
	
}
