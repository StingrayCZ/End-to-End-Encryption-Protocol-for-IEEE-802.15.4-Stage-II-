#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");
#define PRINT


int TestQ(){
	
	printf("Ahoj ONE\n\r");
	
	#ifdef PRINT
	
	printf("Ahoj TWO\n\r");
	
	#endif
	
	
	
}
