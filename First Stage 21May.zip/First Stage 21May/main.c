#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "function.h"


int main ()
{
    int modulus;
    // FROM NEXT ALGORTHM
    int a,b;
    int TESTparameters, TESTmodulo;

    // Obtaining the first point
    int Xfirst, Yfirst, OrderG;

    // Container
    int container[2];

    // SET of MODULUS
    while(TESTmodulo == 0)
    {
        printf ("Napis modulus:\n\r");
        scanf ("%d", &modulus);

        // Examination of modulus
        primeTester(&modulus, &TESTmodulo);

        if(TESTmodulo == 0)
        {
            printf ("Zadane modulo neni prvo cislo, zadej znovu\n\r");
            printf ("\n\r");
        }
    }

    // SET of PARAMETERS
    printf ("Napis a:\n\r");
    scanf ("%d", &a);
    printf ("Napis b:\n\r");
    scanf ("%d", &b);

    // Examination of a and b
    while(TESTparameters == 0)
    {
        printf ("Napis a:\n\r");
        scanf ("%d", &a);
        printf ("Napis b:\n\r");
        scanf ("%d", &b);

        checkValAB(&modulus, &a, &b, &TESTparameters);

        if(TESTmodulo == 0)
        {
            printf ("Zadani parametru nevyhovuje, zadej znovu\n\r");
            printf ("\n\r");
        }
    }


    // Input: modulus, a, b
    // Output: Xfirst, Yfirst, OrderG
    TheFirstPoint(&modulus, &a, &b, &Xfirst, &Yfirst, &OrderG);


    printf("\n\rThe first point is [%d, %d] and order of group is %d", Xfirst, Yfirst, OrderG);
    printf ("\n\r");


    PointComp(&Xfirst, &Yfirst, &a, &modulus, &OrderG, container);

}

