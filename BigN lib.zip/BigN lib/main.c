#include "bigd.h"
int main(void)
{
  BIGD u, v, w;
  /* Create new BIGD objects */
  u = bdNew();
  v = bdNew();
  w = bdNew();

  /* Compute 2 * 0xdeadbeefface */
  bdSetShort(u, 2);
  bdConvFromHex(v, "deadbeefface");
  bdMultiply(w, u, v);

  /* Display the result in hex and decimal */
  bdPrintHex("0x", w, "\n");
  bdPrintDecimal("", w, "\n");

  /* Free all objects we made */
  bdFree(&u);
  bdFree(&v);
  bdFree(&w);
  return 0;
}
