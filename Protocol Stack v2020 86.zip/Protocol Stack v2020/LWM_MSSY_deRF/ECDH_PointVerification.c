/*
 * ECDH.c
 *
 * Created: 29.05.2020 3:09:13
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "ECDH_Functions.h"
#include <stdint.h> // lib for int64_t

//////////////////////////////////
//// VERIFY POINT ////////////////
//////////////////////////////////
void VerifyOfPoint(int64_t *modulus, int64_t *X, int64_t *Y, int64_t *a, int64_t *b, int64_t *returnVAl){

	int64_t mod, x, y, a_pam, b_pam;
	int64_t pow_x, pow_y;

	int64_t resX, resY;

	mod = *modulus;
	x = *X;
	y = *Y;
	a_pam = *a;
	b_pam = *b;

	pow_x = 3;
	pow_y = 2;

	resX = power(&x,&pow_x);
	resX += (a_pam * x + b_pam) ;
	resX = modulo(&resX, &mod);

	resY = power(&y,&pow_y);
	resY = modulo(&resY, &mod);

	if(resX == resY){

		*returnVAl = 1;
	}
	else{
		*returnVAl = 66;
	}

}
