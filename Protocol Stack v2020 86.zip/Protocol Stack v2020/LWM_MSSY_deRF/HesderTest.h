/*
 * HesderTest.h
 *
 * Created: 26.05.2020 23:25:33
 *  Author: jarom
 */ 

int ESTIF();