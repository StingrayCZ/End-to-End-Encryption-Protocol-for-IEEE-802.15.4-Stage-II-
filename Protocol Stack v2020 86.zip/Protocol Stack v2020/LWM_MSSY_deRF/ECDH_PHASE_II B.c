/*
 * CFile2.c
 *
 * Created: 03.06.2020 23:39:59
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "ECDH_Functions.h"
#include <stdint.h> // lib for int64_t


void ECDH_PHASE_BB(int64_t *mod, int64_t *a, int64_t *b, int64_t array[])
{
	int64_t modulus, a_pam, b_pam;
	int64_t OrderG, SecKey;
	int64_t X, Y, iterator;
	int64_t voidValue;   // excess value
	int64_t container[2];




	modulus = *mod;
	a_pam = *a;
	b_pam = *b;

	//Input: mod, a, b
	//Output: Xfirst, Yfirst, OrderG
	TheFirstPoint(&modulus, &a_pam, &b_pam, &X, &Y, &OrderG);

	SecretKey(&OrderG, &SecKey);

	iterator = SecKey;
	iterator += 1;


	PointComp(&X, &Y, &a_pam, &modulus, &iterator, container, &voidValue);


	array[0] = container[0];
	array[1] = container[1];
	array[2] = SecKey;

}