/*
 * CFile2.c
 *
 * Created: 02.06.2020 23:34:36
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "ECDH_Functions.h"
#include <stdint.h> // lib for int64_t


void ECDH_PHASE_BA(int64_t *Order, int64_t *Xf, int64_t *Yf, int64_t *a, int64_t *mod, int64_t array[])
{

	int64_t OrderG, SecKey;
	int64_t X, Y, a_asymptote, modulus, iterator;
	int64_t container[2];

	OrderG = *Order;
	X = *Xf;
	Y = *Yf;
	a_asymptote = *a;
	modulus = *mod;

	SecretKey(&OrderG, &SecKey);

	iterator = SecKey;
	iterator += 1;


	PointComp(&X, &Y, &a_asymptote, &modulus, &iterator, container);


	array[0] = container[0];
	array[1] = container[1];
	array[2] = SecKey;


}