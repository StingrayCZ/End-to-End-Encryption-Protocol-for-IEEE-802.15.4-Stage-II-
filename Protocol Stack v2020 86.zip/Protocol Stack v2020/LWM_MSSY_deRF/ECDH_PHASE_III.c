/*
 * ECDH_PHASE_III.c
 *
 * Created: 02.06.2020 20:46:52
 *  Author: jarom
 */ 


#include <stdio.h>
#include <stdlib.h>
#include "ECDH_Functions.h"

void ECDH_PHASE_C(int64_t *MSKey, int64_t *XF, int64_t *YF, int64_t *XO, int64_t *YO, int64_t *mod, int64_t *a, int64_t *order, int64_t *MutKEY, int64_t MPoint[])
{

	int64_t Xf, Yf;         // coordinates of the first point
	int64_t Xob, Yob;       // coordinates of the obtain point
	int64_t modulus, a_par;

	int64_t MySecKey;
	int64_t ObtainSecKey;
	int64_t MutualKey;

	int64_t OrderG;

	int64_t container[2]; // Mutual Point
	int64_t iterator; // number of iteration


	MySecKey = *MSKey;

	Xf = *XF;
	Yf = *YF;

	Xob = *XO;
	Yob = *YO;

	modulus = *mod;
	a_par = *a;
	OrderG = *order;

	RecognizerSecKey(&Xf, &Yf, &Xob, &Yob, &modulus, &a_par, &ObtainSecKey);

	#ifdef PRINT_ON
	printf("\nRecongnized secret key from other side is %d", ObtainSecKey);
	#endif // PRINT_ON

	Common_Key(&MySecKey, &ObtainSecKey, &OrderG, &MutualKey);

	#ifdef PRINT_ON
	printf("\nMutual key is %d", MutualKey);
	#endif // PRINT_ON



	iterator = MutualKey;
	iterator += 1;

	// Compute mutual point
	PointComp(&Xf, &Yf, &a_par, &modulus, &iterator, container);


	// return result
	*MutKEY = MutualKey;

	MPoint[0] = container[0];
	MPoint[1] = container[1];

}


void Common_Key(int64_t *SecKA, int64_t *SecKB, int64_t *OrderG, int64_t *mutualKey){

	int64_t SecKeyM, SecKeyO, OrdG;

	SecKeyM = *SecKA;
	SecKeyO = *SecKB;
	OrdG = *OrderG;

	SecKeyM *= SecKeyO;
	SecKeyM = modulo(&SecKeyM, &OrdG);

	*mutualKey = SecKeyM;

}


void RecognizerSecKey(int64_t *XF, int64_t *YF, int64_t *XO, int64_t *YO, int64_t *modulus, int64_t *a_par, int64_t *cargo)
{
	int64_t Xo, Yo;
	int64_t Xi, Yi, Xj, Yj;

	int64_t mod, a;
	int64_t counter, StopVal;
	counter = 1;
	StopVal = 1;
	int64_t pole[2];

	// Coordinates of the obtained point from other side
	Xo = *XO;
	Yo = *YO;

	// Coordinates of the fitst point
	Xi = *XF;
	Yi = *YF;

	Xj = Xi;
	Yj = Yi;

	mod = *modulus;
	a = *a_par;


	///////////////////////

	while(StopVal != 2)
	{

		SumTwoPoints(&Xi, &Yi, &Xj, &Yj, &mod, &a, pole);

		Xj = pole[0];
		Yj = pole[1];

		counter ++;

		if (pole[0] == Xo  && pole[1] == Yo)
		{
			StopVal = 2;
		}
	}

	*cargo = counter;

	#ifdef PRINT_ON
	printf("\nBod je [%d, %d]", pole[0], pole[1]);
	printf("\nPoradi je %d", counter);
	#endif // PRINT_ON


}