/*
 * ECDH_Provider.c
 *
 * Created: 28.05.2020 1:32:24
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "ECDH_functions.h"
#include <stdint.h> // lib for int64_t

//////////////////////////////////
//// PROVIDER OF POINT ///////////
//////////////////////////////////

void PointComp(int64_t *X, int64_t *Y, int64_t *a_asymptote, int64_t *modulus, int64_t *iteration, int64_t pole[], int64_t *STOPval)
{
	int64_t Xi, Yi, Xj, Yj;
	int64_t MOD, a;

	int64_t Lambda, X_k, Y_k;   //only within this function
	int64_t result;             //declaration of result
	int64_t iter;

	// Input of value
	Xi = *X;
	Yi = *Y;


	// Copy first point to second, as 1P + 1P = 2P
	Xj = Xi;
	Yj = Yi;

	a = *a_asymptote;
	MOD = *modulus;

	// Value for number of iteration
	iter = *iteration;
	



	for(int64_t i = 1; i <= iter - 2; i++)
	{
		result = Recognizer(&Xi, &Yi, &Xj, &Yj); // Navrat hodnoty, ktera rozhodne, ktera metoda se pouzije

		if(result == 1)
		{
			Lambda = LamdaSame(&MOD, &Xi, &Yi, &a);
			X_k = XSame(&MOD, &Lambda, &Xi);
			Y_k = YSame(&MOD, &Lambda, &Xi, &Yi, &X_k);
			
			#ifdef PRINT_ON
			EMPTYLINE
			//printf("Bod: [%d, %d]\n\r", X_k, Y_k);
			printf("\n\r X je %" PRId32 "\n",  X_k);
			printf("\n\r Y je %" PRId32 "\n",  Y_k);
			#endif // PRINT_ON


			*STOPval = 1;

		}

		else if(result == 2)
		{
			Lambda = LamdaDiff(&MOD, &Xi, &Yi, &Xj, &Yj);
			X_k = XDiff(&MOD, &Lambda, &Xi, &Xj);
			Y_k = YDiff(&MOD, &Lambda, &Xi, &Yi, &X_k);
			
			#ifdef PRINT_ON
			EMPTYLINE
			//printf("Bod: [%d, %d]\n\r", X_k, Y_k);
			printf("\n\r X je %" PRId32 "\n",  X_k);
			printf("\n\r Y je %" PRId32 "\n",  Y_k);
			#endif // PRINT_ONpredani hodnota

			*STOPval = 1;

		}

		else if(result == 66)
		{
			#ifdef PRINT_ON
			printf("Nereseitelne");
			#endif // PRINT_ON

			*STOPval = 66;
		}


		Xj = X_k;
		Yj = Y_k;

	}
	
	#ifdef PRINT_ON
	//    printf("Hodnota X = %d\n\r", X_k);
	//    printf("Hodnota Y = %d\n\r", Y_k);
	#endif // PRINT_ON


	pole[0] = X_k;
	pole[1] = Y_k;

}

//////////////////////////////////
//// LAMBDA SAME /////////////////
//////////////////////////////////
int64_t LamdaSame(int64_t *MOD, int64_t *X, int64_t *Y, int64_t *a)
{

	int64_t cisloX, cisloY, modulus, mocnitel, a_value; // inner data containers
	int64_t HighLine, LowLine, FinalLine;     // auxilary

	cisloX = *X;
	cisloY = *Y;
	modulus = *MOD;
	mocnitel = 2;    // According to Weierstrass equation
	a_value = *a;



	HighLine = 3 * (power(&cisloX, &mocnitel)) + a_value;
	LowLine = 2 * cisloY;

	HighLine = modulo(&HighLine, &modulus);
	LowLine = InverseMod(&LowLine, &modulus);

	FinalLine = HighLine * LowLine;
	FinalLine = modulo(&FinalLine, &modulus);


	return FinalLine;
}

//////////////////////////////////
//// LAMBDA DIFFERENT ////////////
//////////////////////////////////
int64_t LamdaDiff(int64_t *MOD, int64_t *Xi, int64_t *Yi, int64_t *Xj, int64_t *Yj)
{

	int64_t cisloXi, cisloYi, cisloXj, cisloYj, modulus; // inner data containers
	int64_t HighLine, LowLine, FinalLine;                // auxilary

	cisloXi = *Xi;
	cisloYi = *Yi;
	cisloXj = *Xj;
	cisloYj = *Yj;
	modulus = *MOD;


	HighLine = cisloYj - cisloYi;
	LowLine = cisloXj - cisloXi;

	HighLine = modulo(&HighLine, &modulus);
	LowLine = InverseMod(&LowLine, &modulus);

	FinalLine = HighLine * LowLine;
	FinalLine = modulo(&FinalLine, &modulus);


	return FinalLine;

}


//////////////////////////////////
//// X POINT SAME ////////////////
//////////////////////////////////
int64_t XSame(int64_t *MOD, int64_t *Lambda, int64_t *X)
{

	int64_t modulus, lambda, x, mocnitel;

	modulus = *MOD;
	lambda = *Lambda;
	x = *X;
	mocnitel = 2;   // According to Weierstrass equation

	lambda = power(&lambda, &mocnitel);


	lambda -= (2 * x);

	x = modulo(&lambda, &modulus);

	return x;
}

//////////////////////////////////
//// X POINT DIFFERENT ///////////
//////////////////////////////////
int64_t XDiff(int64_t *MOD, int64_t *Lambda, int64_t *Xi, int64_t *Xj)
{

	int64_t modulus, lambda, cisloXi, cisloXj, mocnitel, x_result;

	modulus = *MOD;
	lambda = *Lambda;
	cisloXi = *Xi;
	cisloXj = *Xj;
	mocnitel = 2;   // According to Weierstrass equation

	lambda = power(&lambda, &mocnitel);


	lambda = lambda - cisloXi - cisloXj;

	x_result = modulo(&lambda, &modulus);

	return x_result;
}

//////////////////////////////////
//// Y POINT SAME ////////////////
//////////////////////////////////
int64_t YSame(int64_t *MOD, int64_t *Lambda, int64_t *X, int64_t *Y, int64_t *X_k)
{

	int64_t modulus, lambda, x, y, x_k;

	modulus = *MOD;
	lambda = *Lambda;
	x = *X;
	y = *Y;
	x_k = *X_k;

	y = lambda * (x - x_k) - y;

	y = modulo(&y, &modulus);

	return y;
}

//////////////////////////////////
//// Y POINT DIFFERENT  //////////
//////////////////////////////////

int64_t YDiff(int64_t *MOD, int64_t *Lambda, int64_t *X, int64_t *Y, int64_t *X_k)
{

	int64_t modulus, lambda, x, y, x_k;

	modulus = *MOD;
	lambda = *Lambda;
	x = *X;
	y = *Y;
	x_k = *X_k;

	y = lambda * (x - x_k) - y;

	y = modulo(&y, &modulus);

	return y;

}


//////////////////////////////////
//// DECISION ALGORITHM //////////
//////////////////////////////////
int64_t Recognizer(int64_t *Xi, int64_t *Yi, int64_t *Xj, int64_t *Yj)
{
	int64_t xa, ya, xb, yb;

	xa = *Xi;
	ya = *Yi;

	xb = *Xj;
	yb = *Yj;

	if(xa == xb) // If coordiantes xa and xb are same
	{

		if(ya == yb)  // And also ya and yb are same, will use SAME method, return 1
		{
			if(ya == 0)
			{
				return 66;
			}

			else if(yb == 0)
			{
				return 66;
			}

			else
			{
				return 1;
			}

		}
		else
		{
			return 66; // End of program. This must not happen
		}
	}

	else if(xa != xb)
	{

		return 2;   // will use DIFF method
	}

	return 0;
}