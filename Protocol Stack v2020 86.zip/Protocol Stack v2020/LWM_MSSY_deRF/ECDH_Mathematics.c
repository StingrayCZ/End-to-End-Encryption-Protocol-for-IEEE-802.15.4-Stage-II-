/*
 * ECDH_Mathematics.c
 *
 * Created: 28.05.2020 1:40:56
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> // lib for uint32_t
#include <math.h>
#include <string.h>

#include "ECDH_functions.h"
#include <stdbool.h>

///////////////////
//// Primality ////
///////////////////
int64_t primeTester(int64_t *num, int64_t *result)
{

	int64_t cislo, boolean;

	cislo = *num;
	boolean = true;

	for(int i = cislo - 1; i > 1; i--)
	{
		if(cislo % i == 0)    // for example 4 mod3 = 1; 4 mod2 = 0 => there is no reminder
		{
			boolean = false;
		}
	}

	if(boolean)
	{
		return 1;
	}
	else
	{
		return 2;
	}

	return 0;
}



//////////////////////////////////
//// MODULO //////////////////////
//////////////////////////////////
int64_t modulo (int64_t *num, int64_t *mod)
{

	long tempNum = *num;

	if(tempNum > 0) // Je kladne
	{
		tempNum %= *mod;    // Vypocet modula

		return tempNum;     // Navrat vypocitane hodnoty cyklu
	}

	else if(tempNum < 0)  // Je zaporne
	{
		tempNum *= (-1);  // uprava cisla zpet na kladne

		tempNum %= *mod;  // Vypocet modula

		tempNum = *mod - tempNum;  // Specialni uprava pro zaporne cislo

		return tempNum;    // Navrat vypocitane hodnoty cyklu
	}

	return 0;
}


//////////////////////////////////
//// POWER  //////////////////////
//////////////////////////////////
int64_t power(int64_t *Num, int64_t *PowerNum)
{
	
	int64_t result = (int64_t)(round(pow(*Num, *PowerNum)));

	return result;

}

//////////////////////////////////
//// INVERSE MODULO //////////////
//////////////////////////////////
int64_t InverseMod(int64_t *Num, int64_t *Mod)
{

	int64_t usageNum, multiplier, result;

	usageNum = *Num;
	multiplier = 1;

	if(usageNum > 0)  // Je kladne
	{
		do
		{
			result = (usageNum * multiplier) % *Mod;
			multiplier++;
		}
		while (result >= 2);

		multiplier -= 1; // vyru�en� p?ebyte?n�ho inkrementu

		return multiplier;
	}

	else if (usageNum < 0) // Je zaporne
	{
		usageNum *= (-1);  // uprava cisla zpet na kladne

		do
		{
			result = (usageNum * multiplier) % *Mod;
			multiplier++;
		}
		while (result >= 2);

		multiplier -= 1; // vyru�en� p?ebyte?n�ho inkrementu

		multiplier = *Mod - multiplier;  // Specialni uprava pro zaporne cislo

		return multiplier;
	}

	return 0;
}

