

#include <avr/io.h>
/*- Includes ---------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h> // lib for uint32_
#include <inttypes.h>
#define __STDC_FORMAT_MACROS 1

#include <string.h>
#include <math.h>
#include "config.h"
#include "hal.h"
#include "phy.h"
#include "sys.h"
#include "nwk.h"
#include "sysTimer.h"
#include "halBoard.h"
#include "halUart.h"
//#include "mssy_endpoints.h"
//#include "mssy_requests.h"
#include "mssy_functions.h"
#include "util/delay.h"
#include "ADC_lib.h"
#include "main.h"
#include "sensors_interface.h"

/*- Includes OWN LIB -------------------------------------------------------------*/
#include "ECDH_functions.h"

/////USB//////////////
#include "USB_Stack/usb.h"

/*- Definitions ------------------------------------------------------------*/
#ifdef NWK_ENABLE_SECURITY
#define APP_BUFFER_SIZE     (NWK_MAX_PAYLOAD_SIZE - NWK_SECURITY_MIC_SIZE)
#else
#define APP_BUFFER_SIZE     NWK_MAX_PAYLOAD_SIZE
#endif

/*- Types ------------------------------------------------------------------*/
//typedef enum AppState_t
//{
//APP_STATE_INITIAL,
//APP_STATE_IDLE,
//APP_STATE_PosliC,
//APP_STATE_SLEEP,
//
//
//} AppState_t;

typedef enum {
	
	APP_STATE_INIT_STACK,
	APP_STATE_SEND_PARAMTERES,
	APP_STATE_GOTO_PHASE_B,
	APP_STATE_SEND_COMMON_POINT,
	APP_STATE_GOTO_PHASE_C,
	
} APP_STATES;

APP_STATES state;


// APPSTATES

//static AppState_t appState = APP_STATE_INITIAL;

/*- Prototypes -------------------------------------------------------------*/




/*- Variables --------------------------------------------------------------*/
//static AppState_t appState = APP_STATE_INITIAL;

//timers
static SYS_Timer_t DataSendTimer;   // timer v AppInit
static SYS_Timer_t mujTimer;  // timer

// Set of Payload
static NWK_DataReq_t appDataReq;

// Value of Boolean
static bool appDataReqBusy = false;

// Payload
static NWK_DataReq_t appDataReq;

// ECDH Variables
int64_t mod;
int64_t a_parameter;
int64_t b_parameter;
int64_t  X_first;
int64_t  Y_first;
int64_t Order;
int64_t  X_obtain;
int64_t  Y_obtain;
int64_t MSKey, MutKEY;

int64_t containerB[3];
int64_t containerC[2];


//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
/////// Variables
/////////////////////////////////////////////////////////////////////////////////////////////////////





//#ifdef USB_DEBUG
FILE usb_stream = FDEV_SETUP_STREAM(usb_putc_std, usb_getc_std,_FDEV_SETUP_RW);
//#endif

/*- Implementations --------------------------------------------------------*/

static void appDataConf(NWK_DataReq_t *req)
{
	appDataReqBusy = false;
	(void)req;
}


/*************************************************************************//**
*****************************************************************************/


// PAYLOADS
//*****************************************************************************/
static void appECDH_Payload(void)
{
if (appDataReqBusy)
return;

int64_t DataSend[3];

//memcpy(appDataReqBuffer, appUartBuffer, appUartBufferPtr);

appDataReq.dstAddr = 0xFFFF;
appDataReq.dstEndpoint = APP_ENDPOINT;
appDataReq.srcEndpoint = APP_ENDPOINT;
appDataReq.options = NWK_OPT_ENABLE_SECURITY;
appDataReq.data = DataSend;
appDataReq.size = sizeof(DataSend);
appDataReq.confirm = appDataConf;
NWK_DataReq(&appDataReq);


appDataReqBusy = true;
#ifdef USB_DEBUG
printf("Data sent \n\r");
#endif

printf("Data sent \n\r");
LED0SW;
}



/*************************************************************************//**
*****************************************************************************/

///////////////////////////
/// Timers

static void DataSendTimerHandler(SYS_Timer_t *timer)
{
appECDH_Payload();
}



/*************************************************************************//**
*****************************************************************************/

// Receiver data

static bool appECDHDataReceiver(NWK_DataInd_t *ind)
{

uint16_t address = ind->srcAddr;
volatile uint16_t NodeAddress;
volatile uint16_t NodeAddressa;
volatile uint16_t NodeAddressb;
NodeAddressa= ind->data[0]<<8;
NodeAddressb= ind->data[1];

NodeAddress= NodeAddressa + NodeAddressb;

int8_t rssiX=ind->data[2];
#ifdef USB_DEBUG
printf("We got data from anchor %d: Node: %d, RSSI: %d\n\r", address,NodeAddress,rssiX);
#endif

LED0SW;
//other lines

return true;

}




/*************************************************************************//**
*****************************************************************************/
// NASTAVENI ADRESY, INDENTIFIKATORU
static void appInit(void)
{

// comunication
NWK_SetAddr(APP_ADDR);
NWK_SetPanId(APP_PANID);
PHY_SetChannel(APP_CHANNEL);
#ifdef PHY_AT86RF212
PHY_SetBand(APP_BAND);
PHY_SetModulation(APP_MODULATION);
#endif
PHY_SetRxState(true);

// endpoint


NWK_OpenEndpoint(2, appECDHDataReceiver);


//HAL_BoardInit();
//BoardInit();




DataSendTimer.interval = 600;
DataSendTimer.mode = SYS_TIMER_PERIODIC_MODE;
DataSendTimer.handler = DataSendTimerHandler;



}

/*************************************************************************//**
*****************************************************************************/
//////  TASK HANDLER  ///////////////////

static void APP_TaskHandler(void)
{
switch (state)
{
case APP_STATE_INIT_STACK:
{
appInit();

ECDH_PHASE_A(&mod, &a_parameter, &b_parameter, &X_first, &Y_first, &Order);

if(X_first > 0 && Y_first >0){
state = APP_STATE_SEND_PARAMTERES;
}
break;
}

case APP_STATE_SEND_PARAMTERES:
{
	// send array [2] p, a, b
	SYS_TimerStart(&DataSendTimer);
	
	state = APP_STATE_GOTO_PHASE_B;
	break;
	}
	
	// Incializace C
	//state = APP_STATE_GOTO_PHASE_C;
	//break;


case APP_STATE_GOTO_PHASE_B:
{
	
	ECDH_PHASE_BA(&Order, &X_first, &Y_first, &a_parameter, &mod, containerB);
	
	if(containerB[0] > 0 && containerB[1] >0){
		state = APP_STATE_SEND_COMMON_POINT,;
	}
	
}

case APP_STATE_SEND_COMMON_POINT,:
{
	// send array [1] X, Y
	SYS_TimerStart(&DataSendTimer);
	break;
}

	// Incializace C
	//state = APP_STATE_GOTO_PHASE_C;
	//break;



case APP_STATE_GOTO_PHASE_C:
{

	ECDH_PHASE_C(&MSKey, &X_first;, &Y_first;, &X_obtain, &Y_obtain, &mod, &a_parameter, &Order, &MutKEY, containerC);
	

	break;
}

default:
break;
}
}


/*
static void APP_TaskHandler(void)
{
//STAGE I
int64_t mod, a_parameter, b_parameter, X_first, Y_first, G_Order;
ECDH_PHASE_A(&mod, &a_parameter, &b_parameter, &X_first, &Y_first, &G_Order);


SYS_TimerStart(&DataSendTimer);
//STAGE II

/*

/*************************************************************************/
/*******************************************************************************/


/************************************************************************/
int main(void)
{

//#ifdef USB_DEBUG
usb_init();
/* redirect standard input/output (like printf()) to USB stream */

stdout = &usb_stream;
stdin  = &usb_stream;
//#endif



//int64_t mod, a_parameter, b_parameter, X_first, Y_first, G_Order;
//
//ECDH_PHASE_A(&mod, &a_parameter, &b_parameter, &X_first, &Y_first, &G_Order);
//
//printf("\n\rKEY is -> %" PRId32 "\n", mod);
//printf("\n\rX is -> %" PRId32 "\n", a_parameter);
//printf("\n\rY is -> %" PRId32 "\n", b_parameter);
//printf("\n\rY is -> %" PRId32 "\n", X_first);
//printf("\n\rY is -> %" PRId32 "\n", Y_first);
//printf("\n\rY is -> %" PRId32 "\n", G_Order);


//int64_t MOD, A, B, Xfirst, Yfirst, OrderG;
//
//MOD = 17;
//
//A = 2;
//B = 2;
//
//
//TheFirstPoint(&MOD, &A, &B, &Xfirst, &Yfirst, &OrderG);
//
//printf("\n\rXXXXX is -> %" PRId32 "\n", Xfirst);
//printf("\n\rYYYYY is -> %" PRId32 "\n", Yfirst);
//printf("\n\rOOOOO is -> %" PRId32 "\n", OrderG);


SYS_Init();while(1)
{
SYS_TaskHandler();
APP_TaskHandler();



}

}

