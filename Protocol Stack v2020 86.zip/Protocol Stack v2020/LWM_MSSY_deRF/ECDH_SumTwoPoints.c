/*
 * ECDH_SumTwoPoints.c
 *
 * Created: 01.06.2020 2:28:43
 *  Author: jarom
 */ 

#include <stdio.h>
#include <stdlib.h>
#include "ECDH_Functions.h"
#include <stdint.h> // lib for int64_t

void SumTwoPoints(int64_t *Xa, int64_t *Ya, int64_t *Xb, int64_t *Yb, int64_t *modulus, int64_t *a_pam, int64_t array[])
{

	int64_t mod, a, Xi, Yi, Xj, Yj;
	int64_t Lambda;
	int64_t Xk, Yk;

	mod = *modulus;
	a = *a_pam;

	Xi = *Xa;
	Yi = *Ya;

	Xj = *Xb;
	Yj = *Yb;


	int64_t resultD = Recognizer(&Xi, &Yi, &Xj, &Yj);

	if(resultD == 1)
	{

		Lambda = LamdaSame(&mod, &Xi, &Yi, &a);
		Xk = XSame(&mod, &Lambda, &Xi);
		Yk = YSame(&mod, &Lambda, &Xi, &Yi, &Xk);

	}

	else if(resultD == 2)
	{

		Lambda = LamdaDiff(&mod, &Xi, &Yi, &Xj, &Yj);

		Xk = XDiff(&mod, &Lambda, &Xi, &Xj);
		Yk = YDiff(&mod, &Lambda, &Xi, &Yi, &Xk);
	}

	// return values
	array[0] = Xk;
	array[1] = Yk;

}

