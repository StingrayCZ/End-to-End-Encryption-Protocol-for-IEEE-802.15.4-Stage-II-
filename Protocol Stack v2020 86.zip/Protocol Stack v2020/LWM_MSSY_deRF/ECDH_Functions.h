/*
 * ECDH_Functions.h
 *
 * Created: 28.05.2020 1:29:12
 *  Author: jarom
 */ 

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> // lib for int64_t
#include <inttypes.h>
#define __STDC_FORMAT_MACROS 1

//////////////////////////
/////  PROTOTYPES  ///////
//////////////////////////
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

// ECDH_PointVerification //
void VerifyOfPoint();

// ECDH_Provider //
void PointComp();
int64_t LamdaSame();
int64_t LamdaDiff();
int64_t XSame();
int64_t XDiff();
int64_t YSame();
int64_t YDiff();
int64_t Recognizer();

// ECDH_Mathematics //
int64_t primeTester();
int64_t modulo();
int64_t power();
int64_t InverseMod();


// ECDH_Order //
void checkValAB();
void TheFirstPoint();
void YPart();
void XPart();


// ECDH_SecKey //
void SecretKey();

// ECDH_SumTwoPoints //
void SumTwoPoints();

// ECDH_PHASE_I //
void ECDH_PHASE_A();

// ECDH_PHASE_II A //
void ECDH_PHASE_BA();

// ECDH_PHASE_II B //

// ECDH PHASE III //
void ECDH_PHASE_C();
void Common_Key();
void RecognizerSecKey();

// ECDH PHASE III //
void TEST();


#endif // FUNCTIONS_H


/////////////////////////////
/////  PRINTF FUNCTIONS /////
/////////////////////////////

//#define PRINT_ON    // Switch ON of printf function
#define EMPTYLINE printf("\n\r");