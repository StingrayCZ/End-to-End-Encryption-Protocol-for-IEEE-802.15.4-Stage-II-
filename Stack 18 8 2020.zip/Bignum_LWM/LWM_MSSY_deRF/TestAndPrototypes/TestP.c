#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int TestP(){
	
	EMPTYLINE
	printf("Test prevodu BIGD na int \\n\\r");
	
	//volatile BB pole;
	unsigned char s[1000];
	int num;
	BB v;

	v = bdNew();
	
	bdConvFromHex(v, "4FFD");
	
	//bdSetShort(v, 327634);

	//bdConvToDecimal(v, s, sizeof(s));
	
	bdConvToOctets(v, s, sizeof(s));
	
	printf("String je %s \n\r", s);
	
	num = atoi(s);
	
	
	printf("Integer je %d \n\r", num);
	

		
}
