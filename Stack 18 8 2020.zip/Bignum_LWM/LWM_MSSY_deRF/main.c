/*
 * LWM_MSSY_deRF.c
 *
 * Created: 14.4.2017 12:56:52
 * Author : Ondra
 */ 

#include <avr/io.h>
/*- Includes ---------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "config.h"
#include "hal.h"
#include "phy.h"
#include "sys.h"
#include "nwk.h"
#include "sysTimer.h"
#include "halBoard.h"
#include "halUart.h"
//#include "mssy_endpoints.h"
//#include "mssy_requests.h"
#include "mssy_functions.h"
#include "util/delay.h"
#include "ADC_lib.h"
#include "main.h"
#include "sensors_interface.h"

/////USB//////////////
#include "USB_Stack/usb.h"

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"

#define EMPTYLINE printf("\n\r");
#define BB BIGD

/*- Definitions ------------------------------------------------------------*/
#ifdef NWK_ENABLE_SECURITY
#define APP_BUFFER_SIZE     (NWK_MAX_PAYLOAD_SIZE - NWK_SECURITY_MIC_SIZE)
#else
#define APP_BUFFER_SIZE     NWK_MAX_PAYLOAD_SIZE
#endif

/*- Types ------------------------------------------------------------------*/
typedef enum AppState_t
{
	APP_STATE_Init,
	APP_STATE_FazeA,
	APP_STATE_FazeB,
	APP_STATE_FazeC,
} AppState_t;

/*- Prototypes -------------------------------------------------------------*/
static void appSendData(void);

//int TestB(void);

/*- Variables --------------------------------------------------------------*/
static AppState_t appState = APP_STATE_Init;    // Incialiazation

static SYS_Timer_t appTimerA;
static SYS_Timer_t appTimerB;

static NWK_DataReq_t appDataReq;

static bool appDataReqBusy = false;

// USB printf
FILE usb_stream = FDEV_SETUP_STREAM(usb_putc_std, usb_getc_std,_FDEV_SETUP_RW);

/*- Variables BIGD --------------------------------------------------------------*/
BB MOD, a_parameter, b_parameter;
volatile BB resultsA[2];

//Faze B
BB Order, Xf, Yf;
volatile BB resultsBA[2];
volatile BB resultsBB[2];

///Faze C
BB Xm, Ym, Xo, Yo, KEY;


/*- Implementations --------------------------------------------------------*/

/*************************************************************************//**
*****************************************************************************/
static void appDataConf(NWK_DataReq_t *req)
{
appDataReqBusy = false;
(void)req;
}

/*************************************************************************//**
*****************************************************************************/
static void SendDataA(void)
{
	BB data[6];
	
	data[0] = bdNew();
	data[1] = bdNew();
	data[2] = bdNew();
	data[3] = bdNew();
	data[4] = bdNew();
	data[5] = bdNew();
	
	
	data[0] = MOD;
	data[1] = a_parameter; 
	data[2] = b_parameter;
	data[3] = resultsA[0];  // Xf
	data[4] = resultsA[1];  // Yf
	data[5] = resultsA[2];  // Order
 

	appDataReq.dstAddr = 0xFFFF;
	appDataReq.dstEndpoint = 2;
	appDataReq.srcEndpoint = 1;
	//appDataReq.options = NWK_OPT_ENABLE_SECURITY;
	appDataReq.data = data;
	appDataReq.size = 7;
	appDataReq.confirm = appDataConf;
	NWK_DataReq(&appDataReq);


	appDataReqBusy = true;
	
	
	// Posilam data data
	printf("Odeslana data: ", appDataReq.data);
	
}


static void SendDataBA(void)
{
	BB data[3];
	
	data[0] = bdNew();
	data[1] = bdNew();
	data[2] = bdNew();
	
	
	data[0] = MOD;
	data[1] = a_parameter;
	data[2] = b_parameter;
	

	appDataReq.dstAddr = 0xFFFF;
	appDataReq.dstEndpoint = 3;
	appDataReq.srcEndpoint = 2;
	//appDataReq.options = NWK_OPT_ENABLE_SECURITY;
	appDataReq.data = data;
	appDataReq.size = 7;
	appDataReq.confirm = appDataConf;
	NWK_DataReq(&appDataReq);


	appDataReqBusy = true;
	
	
	// Posilam data data
	printf("Odeslana data: ", appDataReq.data);
	
}



/*************************************************************************//**
*****************************************************************************/
static void SendDataA_TimerHandler(SYS_Timer_t *timer)
{
	SendDataA();
	//(void)timer;  // proc??
}


/*************************************************************************//**
*****************************************************************************/

static bool SendFromAToB_BB(NWK_DataInd_t *ind)  // Version BA
{

	MOD = ind->data[0];
	a_parameter = ind->data[1];
	a_parameter = ind->data[2];
	
	ECDH_PHASE_BB_BIGD(MOD, a_parameter, b_parameter, resultsBB);
	
}


static bool SendFromBToA(NWK_DataInd_t *ind)
{

	
	uint16_t address = ind->srcAddr;
	
	
	// Tisk obdrzenych hodnot

	
}



/*************************************************************************//**
*****************************************************************************/
static void appInit(void)
{
NWK_SetAddr(APP_ADDR);
NWK_SetPanId(APP_PANID);
PHY_SetChannel(APP_CHANNEL);
#ifdef PHY_AT86RF212
PHY_SetBand(APP_BAND);
PHY_SetModulation(APP_MODULATION);
#endif
PHY_SetRxState(true);

//NWK_OpenEndpoint(1, DostavamData);              // Endpoint
//NWK_OpenEndpoint(2, DostavamData);              // Endpoint

//NWK_OpenEndpoint(APP_ENDPOINT, DostavamData);   // Endpoint


//NWK_OpenEndpoint(APP_ENDPOINT, appDataInd);

HAL_BoardInit();

appTimerA.interval = 1000;
//appTimerA.mode = SYS_TIMER_INTERVAL_MODE;
appTimerA.mode = SYS_TIMER_PERIODIC_MODE;
appTimerA.handler = SendDataA_TimerHandler;


}

/*************************************************************************//**
*****************************************************************************/
static void APP_TaskHandler(void)
{
	

	MOD = bdNew();
	a_parameter = bdNew();
	b_parameter = bdNew();
	resultsA[0] = bdNew();
	resultsA[1] = bdNew();
	resultsA[2] = bdNew();
	Order = bdNew();
	Xf = bdNew();
	Yf = bdNew();
	
	resultsBA[0] = bdNew();
	resultsBA[1] = bdNew();
	resultsBA[2] = bdNew();
	
	resultsBB[0] = bdNew();
	resultsBB[1] = bdNew();
	resultsBB[2] = bdNew();

	Xm = bdNew();
	Ym = bdNew();
	Xo = bdNew();
	Yo = bdNew();
	KEY = bdNew();
	
	
switch (appState)
{
case APP_STATE_Init:
{
appInit();


} break;

default:
break;
}
}


/*************************************************************************/
int main(void)
{
	usb_init();
   /* redirect standard input/output (like printf()) to USB stream */
	stdout = &usb_stream;
	stdin  = &usb_stream;
	LED1ON;
	//printf("Hello :-) \n\r");
	

		
	while(1)
	{
		SYS_TaskHandler();
		APP_TaskHandler();
		
	}
}