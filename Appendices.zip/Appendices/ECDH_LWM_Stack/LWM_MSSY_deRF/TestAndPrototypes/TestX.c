#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int TestX(){
	
	
	BB randomN, n;
	
	randomN = bdNew();
	n = bdNew();
	
	bdSetShort(n, 8);
	
	bdRandomNumber(randomN, n);
	
	bdPrintDecimal("randomN", randomN, "\n\r");
	bdPrintDecimal("n", n, "\n\r");
	
}