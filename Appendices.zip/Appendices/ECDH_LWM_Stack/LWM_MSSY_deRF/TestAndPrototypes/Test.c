/*
* Test.c
*
* Created: 07.08.2020 21:25:49
*  Author: jarom
*/

#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD


int TEST(BB a, BB b, BB c, int *primeTest){
	
	BB aa;
	BB bb;
	BB cc;
	BB dd;
	
	assert(a && b && c);
	
	/* Use temp */
	aa = bdNew();
	bb = bdNew();
	cc = bdNew();
	dd = bdNew();
	
	bdSetEqual(aa, a);
	
	bdSetShort(cc, 3);
	
	bdMultiply(aa, b, c);
	
	bdDivide(bb, dd, aa, cc);
	
	*primeTest = fermat_test(bb);
	
	
	bdSetEqual(a,bb);
	
	bdFree(&aa);
	bdFree(&bb);
	bdFree(&cc);
	bdFree(&dd);
	
	return 0;
}
