
#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");



// prevod int na BIGD a naopak

int TestK(){
	
	uint32_t a;
	
	BB X;	
	
	X = bdNew();
	
	
	a = 18446744073709551615;
	
	bdSetShort(X, a);
	
	
	bdPrintDecimal("Tiskni X = ", X, " \n\r");
	
	
	bdFree(&X);




}


//// prevod int na BIGD a naopak
//
//int TestK(){
	//
	//// prevod int na BIGD
	//BB Xseed, Yseed, KeyPattern;
	//BB resultA, resultB, num;
	//
	//uint8_t exponent = 127;
	//int8_t comparsion;
	//
	//
	//Xseed = bdNew();
	//Yseed = bdNew();
	//KeyPattern = bdNew();
	//
	//resultA = bdNew();
	//resultB = bdNew();
	//num = bdNew();
//
	//int X = 305;            // Spolecny bod X
	//int Y = 428;            // Spolecny bod Y
	//
		//
	//bdSetShort(Xseed, X);
	//bdSetShort(Yseed, Y);
		//
	//bdSetShort(num, 2);
	//
	//
//
	//bdPower(KeyPattern, num, exponent);   // 2^128
	//bdDecrement(resultA);
	//
	//
	//
	//
	//bdPrintDecimal("Velikost klice ", KeyPattern, " \n\r");
	//
	//
	////do
	////{
		////bdMultiply(resultB, Xseed, Yseed);
////
		////comparsion = bdCompare(resultB, KeyPattern);
		////
		////
		 ////bdSetEqual(Xseed, resultB);
		 ////
		 ////bdMultiply(resultB, Xseed, Yseed);
			////
		////
		////
	////}while(comparsion != 1);
	//
	//
		//while(comparsion != 1)
		//{
			//bdMultiply(resultB, Xseed, Yseed);
//
			//comparsion = bdCompare(resultB, KeyPattern);
			//
			//
			//bdSetEqual(Xseed, resultB);
			//
			//bdMultiply(resultB, Xseed, Yseed);	
		//}
	//
	//
	//bdPrintDecimal("Vypocitany klic", resultB, " \n\r");
	//
	//printf("Cislo proovnani %d", comparsion);
	//
	//
	//
//
	//
	//// prevod int na BIGD (NAOPAK)
	//
		//
	//
	//return 0;
	//
//}