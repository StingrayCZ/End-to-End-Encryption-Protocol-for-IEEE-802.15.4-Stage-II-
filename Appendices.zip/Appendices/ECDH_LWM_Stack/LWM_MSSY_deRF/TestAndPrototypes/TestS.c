#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int TestS(BB A, BB poleT[]){
	
	EMPTYLINE

	volatile BIGD pole[10];
	BB a;
	
	a = bdNew();
	
	
	bdSetEqual(a, A);
	
	bdPrintDecimal("Testvstupu a", a, "\n\r");
	
	EMPTYLINE
	
	for(int i = 0; i < 10; i++){
		
		//printf("Test %d\n\r", i);
		pole[i]= bdNew();
	}
	
	bdSetShort(pole[0], 227);
	bdSetShort(pole[5], 223);
	
	bdSetEqual(poleT[0], pole[0]);
	bdSetEqual(poleT[5], pole[1]);
	
	bdPrintDecimal("pole[0]", pole[0], "\n\r");
	bdPrintDecimal("pole[1]", pole[5], "\n\r");
	
	for(int i = 0; i < 10; i++){
		
		//printf("Test %d\n\r", i);
		bdFree(&pole[i]);
	}
	
	
}