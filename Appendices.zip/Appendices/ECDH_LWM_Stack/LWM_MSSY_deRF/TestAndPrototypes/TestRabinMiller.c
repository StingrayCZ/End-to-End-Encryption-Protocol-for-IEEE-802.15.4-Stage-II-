
#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");


int TestRB(){
	
	
	BB TestNum;
	
	int result;
	TestNum = bdNew();
	bdConvFromHex(TestNum, "27857BDEF8");   //13

	result = bdRabinMiller(TestNum, 10);
	
	
	EMPTYLINE
	printf("vysledek Rabin Miller testu je %d\n\r", result);
	
	
	return 0;
	
}

