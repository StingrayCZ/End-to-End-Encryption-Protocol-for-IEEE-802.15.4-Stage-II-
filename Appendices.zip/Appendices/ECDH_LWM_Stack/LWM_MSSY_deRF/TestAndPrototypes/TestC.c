#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");


int TestC(){


	BB aa;
	
	aa = bdNew();
	
	bdConvFromHex(aa, "aaefdabceadcbefaadcbbaaaefdabceadcbefaadcbbaaaefdabceadcbefaadcbbaaaefdabceadcbefaadcbbaaaefdabceadcbefaadcbba");
	
	EMPTYLINE
	//vypis DEC hodnoty
	bdPrintDecimal("Pole DEC[5]", aa, "\n\r");
	
	
	bdPrintDecimal("Napis TestC aa ", aa, "\n\r");
	
	//printf("Ahoj Test C, banik C\n\r");
	

	//bdFree(&aa);
	
	return 0;
	
}
