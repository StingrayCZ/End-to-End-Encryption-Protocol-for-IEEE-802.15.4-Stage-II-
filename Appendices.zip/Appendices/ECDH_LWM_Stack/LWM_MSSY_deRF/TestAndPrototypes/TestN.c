#include <stdio.h>
#include <string.h>
#include <assert.h>

/////BIG N libs///////
#include "BigN/bigd.h"
#include "BigN/bigdRand.h"
#define BB BIGD
#define EMPTYLINE printf("\n\r");

int TestN(){
	
	EMPTYLINE
	
	
	BB XA, YA, XB, YB, mod;
	BB resultA, resultAA, resultAAA, resultB, resultBB, resultBBB, resultC, resultD;
	
	int compare;

	
	XA = bdNew();
	YA = bdNew();
	XB = bdNew();
	YB = bdNew();
	mod = bdNew();
	
	
	resultA = bdNew();
	resultAA = bdNew();
	resultAAA = bdNew();
	resultB = bdNew();
	resultBB = bdNew();
	resultBBB = bdNew();
	resultC = bdNew();
	resultD = bdNew();
	
	// 360 - 5 = 355
	//bdConvFromHex(a, "168");  // a = 360
	//bdConvFromHex(b, "5");    // b = 5
	
	
	// 5 - 360 = -355
	bdConvFromHex(XA, "2");   
	bdConvFromHex(YA, "4"); 
	
	
	bdConvFromHex(XB, "6"); 
	bdConvFromHex(YB, "5"); 
	
	
	bdConvFromHex(mod, "7");  // mod  = 34
	
	
	
	////////////////////////////////////////////////////////////////////////////////
	// Y PART
	compare = bdCompare(YB, YA);
	
	if(compare == 1){
		
		printf("Priklad 360 - 5 = 355\n\r");
		bdSubtract(resultA, YB, YA);   // a - b = kladne cislo
		
		EMPTYLINE
		bdPrintDecimal("A je vetsi, vysledek a - b = ", resultA, " \n\r");
		
		bdModulo(resultAAA, resultA, mod);
		
		EMPTYLINE
		bdPrintDecimal("Zbytek po deleni kladneho cisla 355", resultAAA, " \n\r");
		
		
	}
	
	else if(compare == (-1)){
		
		printf("Priklad 5 - 350 = -355\n\r");
		bdSubtract(resultA, YA, YB);   // b - a = kladne cislo
		//
		//EMPTYLINE
		//bdPrintDecimal("B je vetsi, vysledek b - a  = ", resultA, " \n\r");
		//
		
		bdModulo(resultAA, resultA, mod);
		
		bdSubtract(resultAAA, mod, resultAA);
		
		EMPTYLINE
		bdPrintDecimal("Zbytek po deleni zaporneho cisla - 355", resultAAA, " \n\r");
		
	}
	
		
	/////////////////////////////////////////////////////////////////////////	
	// X PART
	compare = bdCompare(XB, XA);
	
	if(compare == 1){
		
		printf("Priklad 360 - 5 = 355\n\r");
		bdSubtract(resultB, XB, XA);   // a - b = kladne cislo
		
		EMPTYLINE
		bdPrintDecimal("A je vetsi, vysledek a - b = ", resultB, " \n\r");
		
		bdModInv(resultBBB, resultB, mod);
		
		EMPTYLINE
		bdPrintDecimal("Zbytek po deleni kladneho cisla 355", resultBBB, " \n\r");
		
		
		
	}
	
	else if(compare == (-1)){
		
		printf("Priklad 5 - 350 = -355\n\r");
		bdSubtract(resultB, XA, XB);   // b - a = kladne cislo
		//
		//EMPTYLINE
		//bdPrintDecimal("B je vetsi, vysledek b - a  = ", resultA, " \n\r");
		//
		
		bdModInv(resultBB, resultB, mod);
		
		bdSubtract(resultBBB, mod, resultBB);
		
		EMPTYLINE
		bdPrintDecimal("Zbytek po deleni zaporneho cisla - 355", resultBBB, " \n\r");
		
	}
	
	
	bdMultiply(resultC, resultAAA, resultBBB);
	
	bdModulo(resultD, resultC, mod);
	
	
	EMPTYLINE
	bdPrintDecimal("Total = ", resultD, " \n\r");
	
	
	
	bdFree(&XA);
	bdFree(&YA);
	bdFree(&XB);
	bdFree(&YB);
	bdFree(&mod);
	
	bdFree(&resultA);
	bdFree(&resultAA);
	bdFree(&resultAAA);
	bdFree(&resultB);
	bdFree(&resultBB);
	bdFree(&resultBBB);
	bdFree(&resultC);
	bdFree(&resultD);

}